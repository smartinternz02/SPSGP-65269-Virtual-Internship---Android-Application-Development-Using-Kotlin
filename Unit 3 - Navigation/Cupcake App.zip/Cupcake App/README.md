# Cupcake-app
This app contains an order flow for cupcakes with options for quantity, flavor, and pickup date.
The order details get displayed on an order summary screen and can be shared to another app to
send the order.

This app demonstrates multiple fragments in an activity, a shared ViewModel across fragments,
data binding, LiveData, and the Jetpack Navigation component.


## Authors

- [@Satyamkumarnavneet](https://www.github.com/Satyamkumarnavneet)

## Run Locally

Clone the project

```bash
  git clone https://github.com/Satyamkumarnavneet/Cupcake-app.git
```

## Support

For support, email navneetsatyamkumar@gmail.com.com
## Feedback

If you have any feedback, please reach out to me at navneetsatyamkumar@gmail.com

